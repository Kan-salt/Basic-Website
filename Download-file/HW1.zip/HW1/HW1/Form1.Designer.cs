﻿namespace HW1
{
    partial class Form_AddressBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_Name = new System.Windows.Forms.Label();
            this.Label_Surname = new System.Windows.Forms.Label();
            this.Label_PhoneNum = new System.Windows.Forms.Label();
            this.Label_Email = new System.Windows.Forms.Label();
            this.Label_Gender = new System.Windows.Forms.Label();
            this.Label_BirthDate = new System.Windows.Forms.Label();
            this.Label_AddressTitle = new System.Windows.Forms.Label();
            this.Label_Country = new System.Windows.Forms.Label();
            this.Label_Nation = new System.Windows.Forms.Label();
            this.Label_Province = new System.Windows.Forms.Label();
            this.Label_Postal = new System.Windows.Forms.Label();
            this.Label_Street = new System.Windows.Forms.Label();
            this.Label_District = new System.Windows.Forms.Label();
            this.Label_SubDistrict = new System.Windows.Forms.Label();
            this.Label_Address = new System.Windows.Forms.Label();
            this.Label_Age = new System.Windows.Forms.Label();
            this.Label_Status = new System.Windows.Forms.Label();
            this.Label_AddressAddon = new System.Windows.Forms.Label();
            this.Label_Job = new System.Windows.Forms.Label();
            this.Label_Personal_Info = new System.Windows.Forms.Label();
            this.ComboBox_BirthMonth = new System.Windows.Forms.ComboBox();
            this.ComboBox_BirthDate = new System.Windows.Forms.ComboBox();
            this.textBox_BirthYear = new System.Windows.Forms.TextBox();
            this.TextBox_Name = new System.Windows.Forms.TextBox();
            this.TextBox_Surname = new System.Windows.Forms.TextBox();
            this.TextBox_Nation = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.ComboBox_Status = new System.Windows.Forms.ComboBox();
            this.TextBox_Age = new System.Windows.Forms.TextBox();
            this.TextBox_PhoneNum = new System.Windows.Forms.TextBox();
            this.TextBox_Email = new System.Windows.Forms.TextBox();
            this.TextBox_Job = new System.Windows.Forms.TextBox();
            this.TextBox_Country = new System.Windows.Forms.TextBox();
            this.TextBox_Province = new System.Windows.Forms.TextBox();
            this.TextBox_Postal = new System.Windows.Forms.TextBox();
            this.TextBox_District = new System.Windows.Forms.TextBox();
            this.TextBox_SubDistrict = new System.Windows.Forms.TextBox();
            this.TextBox_Street = new System.Windows.Forms.TextBox();
            this.TextBox_Address = new System.Windows.Forms.TextBox();
            this.TextBox_AddressAddon = new System.Windows.Forms.TextBox();
            this.Button_Save = new System.Windows.Forms.Button();
            this.Button_ClearPage = new System.Windows.Forms.Button();
            this.TextBox_OutputBeforeSave = new System.Windows.Forms.TextBox();
            this.Button_LoadPreview = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Label_Name
            // 
            this.Label_Name.AutoSize = true;
            this.Label_Name.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Name.Location = new System.Drawing.Point(18, 74);
            this.Label_Name.Name = "Label_Name";
            this.Label_Name.Size = new System.Drawing.Size(49, 37);
            this.Label_Name.TabIndex = 0;
            this.Label_Name.Text = "ชื่อ :";
            this.Label_Name.Click += new System.EventHandler(this.Label_Name_Click);
            // 
            // Label_Surname
            // 
            this.Label_Surname.AutoSize = true;
            this.Label_Surname.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Surname.Location = new System.Drawing.Point(276, 74);
            this.Label_Surname.Name = "Label_Surname";
            this.Label_Surname.Size = new System.Drawing.Size(94, 37);
            this.Label_Surname.TabIndex = 1;
            this.Label_Surname.Text = "นามสกุล :";
            this.Label_Surname.Click += new System.EventHandler(this.label1_Click);
            // 
            // Label_PhoneNum
            // 
            this.Label_PhoneNum.AutoSize = true;
            this.Label_PhoneNum.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_PhoneNum.Location = new System.Drawing.Point(18, 184);
            this.Label_PhoneNum.Name = "Label_PhoneNum";
            this.Label_PhoneNum.Size = new System.Drawing.Size(136, 37);
            this.Label_PhoneNum.TabIndex = 2;
            this.Label_PhoneNum.Text = "เบอร์โทรศัพท์ :";
            // 
            // Label_Email
            // 
            this.Label_Email.AutoSize = true;
            this.Label_Email.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Email.Location = new System.Drawing.Point(346, 184);
            this.Label_Email.Name = "Label_Email";
            this.Label_Email.Size = new System.Drawing.Size(66, 37);
            this.Label_Email.TabIndex = 3;
            this.Label_Email.Text = "อีเมล :";
            this.Label_Email.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // Label_Gender
            // 
            this.Label_Gender.AutoSize = true;
            this.Label_Gender.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Gender.Location = new System.Drawing.Point(570, 74);
            this.Label_Gender.Name = "Label_Gender";
            this.Label_Gender.Size = new System.Drawing.Size(56, 37);
            this.Label_Gender.TabIndex = 4;
            this.Label_Gender.Text = "เพศ :";
            // 
            // Label_BirthDate
            // 
            this.Label_BirthDate.AutoSize = true;
            this.Label_BirthDate.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_BirthDate.Location = new System.Drawing.Point(17, 125);
            this.Label_BirthDate.Name = "Label_BirthDate";
            this.Label_BirthDate.Size = new System.Drawing.Size(175, 37);
            this.Label_BirthDate.TabIndex = 5;
            this.Label_BirthDate.Text = "วันเกิด(วัน/เดือน/ปี) :";
            this.Label_BirthDate.Click += new System.EventHandler(this.Label_BirthDate_Click);
            // 
            // Label_AddressTitle
            // 
            this.Label_AddressTitle.AutoSize = true;
            this.Label_AddressTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label_AddressTitle.Font = new System.Drawing.Font("Angsana New", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_AddressTitle.Location = new System.Drawing.Point(12, 253);
            this.Label_AddressTitle.Name = "Label_AddressTitle";
            this.Label_AddressTitle.Size = new System.Drawing.Size(155, 56);
            this.Label_AddressTitle.TabIndex = 6;
            this.Label_AddressTitle.Text = "ที่อยู่ปัจจุบัน";
            // 
            // Label_Country
            // 
            this.Label_Country.AutoSize = true;
            this.Label_Country.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Country.Location = new System.Drawing.Point(18, 320);
            this.Label_Country.Name = "Label_Country";
            this.Label_Country.Size = new System.Drawing.Size(89, 37);
            this.Label_Country.TabIndex = 7;
            this.Label_Country.Text = "ประเทศ :";
            this.Label_Country.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // Label_Nation
            // 
            this.Label_Nation.AutoSize = true;
            this.Label_Nation.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Nation.Location = new System.Drawing.Point(478, 125);
            this.Label_Nation.Name = "Label_Nation";
            this.Label_Nation.Size = new System.Drawing.Size(84, 37);
            this.Label_Nation.TabIndex = 8;
            this.Label_Nation.Text = "สัญชาติ :";
            // 
            // Label_Province
            // 
            this.Label_Province.AutoSize = true;
            this.Label_Province.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Province.Location = new System.Drawing.Point(494, 368);
            this.Label_Province.Name = "Label_Province";
            this.Label_Province.Size = new System.Drawing.Size(80, 37);
            this.Label_Province.TabIndex = 9;
            this.Label_Province.Text = "จังหวัด :";
            // 
            // Label_Postal
            // 
            this.Label_Postal.AutoSize = true;
            this.Label_Postal.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Postal.Location = new System.Drawing.Point(729, 368);
            this.Label_Postal.Name = "Label_Postal";
            this.Label_Postal.Size = new System.Drawing.Size(132, 37);
            this.Label_Postal.TabIndex = 10;
            this.Label_Postal.Text = "รหัสไปรษณีย์ :";
            // 
            // Label_Street
            // 
            this.Label_Street.AutoSize = true;
            this.Label_Street.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Street.Location = new System.Drawing.Point(286, 368);
            this.Label_Street.Name = "Label_Street";
            this.Label_Street.Size = new System.Drawing.Size(64, 37);
            this.Label_Street.TabIndex = 11;
            this.Label_Street.Text = "ถนน :";
            // 
            // Label_District
            // 
            this.Label_District.AutoSize = true;
            this.Label_District.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_District.Location = new System.Drawing.Point(561, 315);
            this.Label_District.Name = "Label_District";
            this.Label_District.Size = new System.Drawing.Size(106, 37);
            this.Label_District.TabIndex = 12;
            this.Label_District.Text = "เขต/อำเภอ :";
            // 
            // Label_SubDistrict
            // 
            this.Label_SubDistrict.AutoSize = true;
            this.Label_SubDistrict.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SubDistrict.Location = new System.Drawing.Point(18, 368);
            this.Label_SubDistrict.Name = "Label_SubDistrict";
            this.Label_SubDistrict.Size = new System.Drawing.Size(116, 37);
            this.Label_SubDistrict.TabIndex = 13;
            this.Label_SubDistrict.Text = "ตำบล/แขวง :";
            // 
            // Label_Address
            // 
            this.Label_Address.AutoSize = true;
            this.Label_Address.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Address.Location = new System.Drawing.Point(276, 316);
            this.Label_Address.Name = "Label_Address";
            this.Label_Address.Size = new System.Drawing.Size(88, 37);
            this.Label_Address.TabIndex = 14;
            this.Label_Address.Text = "เลขที่อยู่ :";
            // 
            // Label_Age
            // 
            this.Label_Age.AutoSize = true;
            this.Label_Age.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Age.Location = new System.Drawing.Point(709, 125);
            this.Label_Age.Name = "Label_Age";
            this.Label_Age.Size = new System.Drawing.Size(56, 37);
            this.Label_Age.TabIndex = 15;
            this.Label_Age.Text = "อายุ :";
            // 
            // Label_Status
            // 
            this.Label_Status.AutoSize = true;
            this.Label_Status.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Status.Location = new System.Drawing.Point(699, 74);
            this.Label_Status.Name = "Label_Status";
            this.Label_Status.Size = new System.Drawing.Size(179, 37);
            this.Label_Status.TabIndex = 16;
            this.Label_Status.Text = "สถานภาพการสมรส :";
            // 
            // Label_AddressAddon
            // 
            this.Label_AddressAddon.AutoSize = true;
            this.Label_AddressAddon.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_AddressAddon.Location = new System.Drawing.Point(17, 415);
            this.Label_AddressAddon.Name = "Label_AddressAddon";
            this.Label_AddressAddon.Size = new System.Drawing.Size(147, 37);
            this.Label_AddressAddon.TabIndex = 17;
            this.Label_AddressAddon.Text = "รายละเอียดที่อยู่ :";
            // 
            // Label_Job
            // 
            this.Label_Job.AutoSize = true;
            this.Label_Job.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Job.Location = new System.Drawing.Point(721, 184);
            this.Label_Job.Name = "Label_Job";
            this.Label_Job.Size = new System.Drawing.Size(70, 37);
            this.Label_Job.TabIndex = 18;
            this.Label_Job.Text = "อาชีพ :";
            // 
            // Label_Personal_Info
            // 
            this.Label_Personal_Info.AutoSize = true;
            this.Label_Personal_Info.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Label_Personal_Info.Font = new System.Drawing.Font("Angsana New", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Personal_Info.Location = new System.Drawing.Point(12, 9);
            this.Label_Personal_Info.Name = "Label_Personal_Info";
            this.Label_Personal_Info.Size = new System.Drawing.Size(170, 56);
            this.Label_Personal_Info.TabIndex = 19;
            this.Label_Personal_Info.Text = "ข้อมูลส่วนตัว";
            this.Label_Personal_Info.Click += new System.EventHandler(this.Label_Personal_Info_Click);
            // 
            // ComboBox_BirthMonth
            // 
            this.ComboBox_BirthMonth.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.ComboBox_BirthMonth.FormattingEnabled = true;
            this.ComboBox_BirthMonth.Items.AddRange(new object[] {
            "มกราคม",
            "กุมภาพันธุ์",
            "มีนาคม",
            "เมษายน",
            "พฤษภาคม",
            "มิถุนายน",
            "กรกฎาคม",
            "สิงหาคม",
            "กันยายน",
            "ตุลาคม",
            "พฤศจิกายน",
            "ธันวาคม"});
            this.ComboBox_BirthMonth.Location = new System.Drawing.Point(262, 122);
            this.ComboBox_BirthMonth.Name = "ComboBox_BirthMonth";
            this.ComboBox_BirthMonth.Size = new System.Drawing.Size(121, 44);
            this.ComboBox_BirthMonth.TabIndex = 20;
            // 
            // ComboBox_BirthDate
            // 
            this.ComboBox_BirthDate.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.ComboBox_BirthDate.FormattingEnabled = true;
            this.ComboBox_BirthDate.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.ComboBox_BirthDate.Location = new System.Drawing.Point(188, 122);
            this.ComboBox_BirthDate.Name = "ComboBox_BirthDate";
            this.ComboBox_BirthDate.Size = new System.Drawing.Size(68, 44);
            this.ComboBox_BirthDate.TabIndex = 21;
            // 
            // textBox_BirthYear
            // 
            this.textBox_BirthYear.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.textBox_BirthYear.Location = new System.Drawing.Point(389, 122);
            this.textBox_BirthYear.Name = "textBox_BirthYear";
            this.textBox_BirthYear.Size = new System.Drawing.Size(81, 44);
            this.textBox_BirthYear.TabIndex = 22;
            // 
            // TextBox_Name
            // 
            this.TextBox_Name.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_Name.Location = new System.Drawing.Point(63, 71);
            this.TextBox_Name.Name = "TextBox_Name";
            this.TextBox_Name.Size = new System.Drawing.Size(207, 44);
            this.TextBox_Name.TabIndex = 23;
            // 
            // TextBox_Surname
            // 
            this.TextBox_Surname.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_Surname.Location = new System.Drawing.Point(362, 72);
            this.TextBox_Surname.Name = "TextBox_Surname";
            this.TextBox_Surname.Size = new System.Drawing.Size(202, 44);
            this.TextBox_Surname.TabIndex = 24;
            // 
            // TextBox_Nation
            // 
            this.TextBox_Nation.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_Nation.Location = new System.Drawing.Point(558, 122);
            this.TextBox_Nation.Name = "TextBox_Nation";
            this.TextBox_Nation.Size = new System.Drawing.Size(145, 44);
            this.TextBox_Nation.TabIndex = 25;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "ชาย",
            "หญิง",
            "ไม่ระบุ",
            "อื่นๆ"});
            this.comboBox1.Location = new System.Drawing.Point(622, 71);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(75, 44);
            this.comboBox1.TabIndex = 26;
            // 
            // ComboBox_Status
            // 
            this.ComboBox_Status.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.ComboBox_Status.FormattingEnabled = true;
            this.ComboBox_Status.Items.AddRange(new object[] {
            "โสด",
            "สมรถ",
            "หย่า",
            "หม้าย",
            "แยกกันอยู่"});
            this.ComboBox_Status.Location = new System.Drawing.Point(884, 67);
            this.ComboBox_Status.Name = "ComboBox_Status";
            this.ComboBox_Status.Size = new System.Drawing.Size(86, 44);
            this.ComboBox_Status.TabIndex = 27;
            // 
            // TextBox_Age
            // 
            this.TextBox_Age.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_Age.Location = new System.Drawing.Point(760, 122);
            this.TextBox_Age.Name = "TextBox_Age";
            this.TextBox_Age.Size = new System.Drawing.Size(92, 44);
            this.TextBox_Age.TabIndex = 28;
            // 
            // TextBox_PhoneNum
            // 
            this.TextBox_PhoneNum.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_PhoneNum.Location = new System.Drawing.Point(150, 181);
            this.TextBox_PhoneNum.Name = "TextBox_PhoneNum";
            this.TextBox_PhoneNum.Size = new System.Drawing.Size(190, 44);
            this.TextBox_PhoneNum.TabIndex = 29;
            // 
            // TextBox_Email
            // 
            this.TextBox_Email.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_Email.Location = new System.Drawing.Point(408, 181);
            this.TextBox_Email.Name = "TextBox_Email";
            this.TextBox_Email.Size = new System.Drawing.Size(307, 44);
            this.TextBox_Email.TabIndex = 30;
            // 
            // TextBox_Job
            // 
            this.TextBox_Job.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_Job.Location = new System.Drawing.Point(787, 181);
            this.TextBox_Job.Name = "TextBox_Job";
            this.TextBox_Job.Size = new System.Drawing.Size(183, 44);
            this.TextBox_Job.TabIndex = 31;
            // 
            // TextBox_Country
            // 
            this.TextBox_Country.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_Country.Location = new System.Drawing.Point(103, 312);
            this.TextBox_Country.Name = "TextBox_Country";
            this.TextBox_Country.Size = new System.Drawing.Size(167, 44);
            this.TextBox_Country.TabIndex = 32;
            // 
            // TextBox_Province
            // 
            this.TextBox_Province.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_Province.Location = new System.Drawing.Point(570, 365);
            this.TextBox_Province.Name = "TextBox_Province";
            this.TextBox_Province.Size = new System.Drawing.Size(144, 44);
            this.TextBox_Province.TabIndex = 33;
            // 
            // TextBox_Postal
            // 
            this.TextBox_Postal.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_Postal.Location = new System.Drawing.Point(867, 365);
            this.TextBox_Postal.Name = "TextBox_Postal";
            this.TextBox_Postal.Size = new System.Drawing.Size(103, 44);
            this.TextBox_Postal.TabIndex = 34;
            // 
            // TextBox_District
            // 
            this.TextBox_District.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_District.Location = new System.Drawing.Point(663, 309);
            this.TextBox_District.Name = "TextBox_District";
            this.TextBox_District.Size = new System.Drawing.Size(165, 44);
            this.TextBox_District.TabIndex = 35;
            // 
            // TextBox_SubDistrict
            // 
            this.TextBox_SubDistrict.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_SubDistrict.Location = new System.Drawing.Point(130, 365);
            this.TextBox_SubDistrict.Name = "TextBox_SubDistrict";
            this.TextBox_SubDistrict.Size = new System.Drawing.Size(149, 44);
            this.TextBox_SubDistrict.TabIndex = 36;
            // 
            // TextBox_Street
            // 
            this.TextBox_Street.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_Street.Location = new System.Drawing.Point(346, 365);
            this.TextBox_Street.Name = "TextBox_Street";
            this.TextBox_Street.Size = new System.Drawing.Size(142, 44);
            this.TextBox_Street.TabIndex = 37;
            // 
            // TextBox_Address
            // 
            this.TextBox_Address.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_Address.Location = new System.Drawing.Point(360, 312);
            this.TextBox_Address.Name = "TextBox_Address";
            this.TextBox_Address.Size = new System.Drawing.Size(195, 44);
            this.TextBox_Address.TabIndex = 38;
            // 
            // TextBox_AddressAddon
            // 
            this.TextBox_AddressAddon.Font = new System.Drawing.Font("Angsana New", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_AddressAddon.Location = new System.Drawing.Point(160, 415);
            this.TextBox_AddressAddon.Name = "TextBox_AddressAddon";
            this.TextBox_AddressAddon.Size = new System.Drawing.Size(810, 44);
            this.TextBox_AddressAddon.TabIndex = 39;
            // 
            // Button_Save
            // 
            this.Button_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Button_Save.Font = new System.Drawing.Font("Angsana New", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Button_Save.Location = new System.Drawing.Point(771, 477);
            this.Button_Save.Name = "Button_Save";
            this.Button_Save.Size = new System.Drawing.Size(199, 114);
            this.Button_Save.TabIndex = 40;
            this.Button_Save.Text = "บันทึก";
            this.Button_Save.UseVisualStyleBackColor = false;
            // 
            // Button_ClearPage
            // 
            this.Button_ClearPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Button_ClearPage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Button_ClearPage.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Button_ClearPage.Font = new System.Drawing.Font("Angsana New", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Button_ClearPage.Location = new System.Drawing.Point(12, 477);
            this.Button_ClearPage.Name = "Button_ClearPage";
            this.Button_ClearPage.Size = new System.Drawing.Size(203, 114);
            this.Button_ClearPage.TabIndex = 41;
            this.Button_ClearPage.Text = "ล้างข้อมูล";
            this.Button_ClearPage.UseVisualStyleBackColor = false;
            // 
            // TextBox_OutputBeforeSave
            // 
            this.TextBox_OutputBeforeSave.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.TextBox_OutputBeforeSave.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TextBox_OutputBeforeSave.Font = new System.Drawing.Font("Angsana New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.TextBox_OutputBeforeSave.Location = new System.Drawing.Point(976, 71);
            this.TextBox_OutputBeforeSave.Multiline = true;
            this.TextBox_OutputBeforeSave.Name = "TextBox_OutputBeforeSave";
            this.TextBox_OutputBeforeSave.Size = new System.Drawing.Size(294, 520);
            this.TextBox_OutputBeforeSave.TabIndex = 42;
            // 
            // Button_LoadPreview
            // 
            this.Button_LoadPreview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Button_LoadPreview.Font = new System.Drawing.Font("Angsana New", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Button_LoadPreview.Location = new System.Drawing.Point(589, 477);
            this.Button_LoadPreview.Name = "Button_LoadPreview";
            this.Button_LoadPreview.Size = new System.Drawing.Size(176, 114);
            this.Button_LoadPreview.TabIndex = 43;
            this.Button_LoadPreview.Text = "โหลด";
            this.Button_LoadPreview.UseVisualStyleBackColor = false;
            // 
            // Form_AddressBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1282, 603);
            this.Controls.Add(this.Button_LoadPreview);
            this.Controls.Add(this.TextBox_OutputBeforeSave);
            this.Controls.Add(this.Button_ClearPage);
            this.Controls.Add(this.Button_Save);
            this.Controls.Add(this.TextBox_AddressAddon);
            this.Controls.Add(this.TextBox_Address);
            this.Controls.Add(this.TextBox_Street);
            this.Controls.Add(this.TextBox_SubDistrict);
            this.Controls.Add(this.TextBox_District);
            this.Controls.Add(this.TextBox_Postal);
            this.Controls.Add(this.TextBox_Province);
            this.Controls.Add(this.TextBox_Country);
            this.Controls.Add(this.TextBox_Job);
            this.Controls.Add(this.TextBox_Email);
            this.Controls.Add(this.TextBox_PhoneNum);
            this.Controls.Add(this.TextBox_Age);
            this.Controls.Add(this.ComboBox_Status);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.TextBox_Nation);
            this.Controls.Add(this.TextBox_Surname);
            this.Controls.Add(this.TextBox_Name);
            this.Controls.Add(this.textBox_BirthYear);
            this.Controls.Add(this.ComboBox_BirthDate);
            this.Controls.Add(this.ComboBox_BirthMonth);
            this.Controls.Add(this.Label_Personal_Info);
            this.Controls.Add(this.Label_Job);
            this.Controls.Add(this.Label_AddressAddon);
            this.Controls.Add(this.Label_Status);
            this.Controls.Add(this.Label_Age);
            this.Controls.Add(this.Label_Address);
            this.Controls.Add(this.Label_SubDistrict);
            this.Controls.Add(this.Label_District);
            this.Controls.Add(this.Label_Street);
            this.Controls.Add(this.Label_Postal);
            this.Controls.Add(this.Label_Province);
            this.Controls.Add(this.Label_Nation);
            this.Controls.Add(this.Label_Country);
            this.Controls.Add(this.Label_AddressTitle);
            this.Controls.Add(this.Label_BirthDate);
            this.Controls.Add(this.Label_Gender);
            this.Controls.Add(this.Label_Email);
            this.Controls.Add(this.Label_PhoneNum);
            this.Controls.Add(this.Label_Surname);
            this.Controls.Add(this.Label_Name);
            this.Name = "Form_AddressBook";
            this.Text = "Address Book";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label_Name;
        private System.Windows.Forms.Label Label_Surname;
        private System.Windows.Forms.Label Label_PhoneNum;
        private System.Windows.Forms.Label Label_Email;
        private System.Windows.Forms.Label Label_Gender;
        private System.Windows.Forms.Label Label_BirthDate;
        private System.Windows.Forms.Label Label_AddressTitle;
        private System.Windows.Forms.Label Label_Country;
        private System.Windows.Forms.Label Label_Nation;
        private System.Windows.Forms.Label Label_Province;
        private System.Windows.Forms.Label Label_Postal;
        private System.Windows.Forms.Label Label_Street;
        private System.Windows.Forms.Label Label_District;
        private System.Windows.Forms.Label Label_SubDistrict;
        private System.Windows.Forms.Label Label_Address;
        private System.Windows.Forms.Label Label_Age;
        private System.Windows.Forms.Label Label_Status;
        private System.Windows.Forms.Label Label_AddressAddon;
        private System.Windows.Forms.Label Label_Job;
        private System.Windows.Forms.Label Label_Personal_Info;
        private System.Windows.Forms.ComboBox ComboBox_BirthMonth;
        private System.Windows.Forms.ComboBox ComboBox_BirthDate;
        private System.Windows.Forms.TextBox textBox_BirthYear;
        private System.Windows.Forms.TextBox TextBox_Name;
        private System.Windows.Forms.TextBox TextBox_Surname;
        private System.Windows.Forms.TextBox TextBox_Nation;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox ComboBox_Status;
        private System.Windows.Forms.TextBox TextBox_Age;
        private System.Windows.Forms.TextBox TextBox_PhoneNum;
        private System.Windows.Forms.TextBox TextBox_Email;
        private System.Windows.Forms.TextBox TextBox_Job;
        private System.Windows.Forms.TextBox TextBox_Country;
        private System.Windows.Forms.TextBox TextBox_Province;
        private System.Windows.Forms.TextBox TextBox_Postal;
        private System.Windows.Forms.TextBox TextBox_District;
        private System.Windows.Forms.TextBox TextBox_SubDistrict;
        private System.Windows.Forms.TextBox TextBox_Street;
        private System.Windows.Forms.TextBox TextBox_Address;
        private System.Windows.Forms.TextBox TextBox_AddressAddon;
        private System.Windows.Forms.Button Button_Save;
        private System.Windows.Forms.Button Button_ClearPage;
        private System.Windows.Forms.TextBox TextBox_OutputBeforeSave;
        private System.Windows.Forms.Button Button_LoadPreview;
    }
}


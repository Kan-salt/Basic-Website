﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW1
{
    public partial class Form_AddressBook : Form
    {
        private const string CSV_FILE_NAME = "Data.csv";

        public Form_AddressBook()
        {
            InitializeComponent();
            // Wire up button events (in case not already in designer)
            this.Button_LoadPreview.Click += Button_LoadPreview_Click;
            this.Button_Save.Click += Button_Save_Click;
            this.Button_ClearPage.Click += Button_ClearPage_Click;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        #region Button Event Handlers

        private void Button_LoadPreview_Click(object sender, EventArgs e)
        {
            TextBox_OutputBeforeSave.Clear();

            // Collect all data
            string name = TextBox_Name.Text.Trim();
            string surname = TextBox_Surname.Text.Trim();
            string gender = comboBox1.SelectedItem?.ToString() ?? "";
            string birthDay = ComboBox_BirthDate.SelectedItem?.ToString() ?? "";
            string birthMonth = ComboBox_BirthMonth.SelectedItem?.ToString() ?? "";
            string birthYear = textBox_BirthYear.Text.Trim();
            string nation = TextBox_Nation.Text.Trim();
            string age = TextBox_Age.Text.Trim();
            string maritalStatus = ComboBox_Status.SelectedItem?.ToString() ?? "";
            string phone = TextBox_PhoneNum.Text.Trim();
            string email = TextBox_Email.Text.Trim();
            string job = TextBox_Job.Text.Trim();
            string country = TextBox_Country.Text.Trim();
            string addressNum = TextBox_Address.Text.Trim();
            string district = TextBox_District.Text.Trim();
            string subDistrict = TextBox_SubDistrict.Text.Trim();
            string street = TextBox_Street.Text.Trim();
            string province = TextBox_Province.Text.Trim();
            string postal = TextBox_Postal.Text.Trim();
            string addressAddon = TextBox_AddressAddon.Text.Trim();

            StringBuilder preview = new StringBuilder();
            preview.AppendLine("=== ข้อมูลส่วนตัว ===");
            preview.AppendLine($"ชื่อ-นามสกุล: {name} {surname}");
            preview.AppendLine($"เพศ: {gender}");
            preview.AppendLine($"วันเกิด: {birthDay} {birthMonth} {birthYear}");
            preview.AppendLine($"สัญชาติ: {nation} | อายุ: {age}");
            preview.AppendLine($"สถานภาพ: {maritalStatus}");
            preview.AppendLine($"เบอร์โทร: {phone} | อีเมล: {email} | อาชีพ: {job}");
            preview.AppendLine("");
            preview.AppendLine("=== ที่อยู่ปัจจุบัน ===");
            preview.AppendLine($"ประเทศ: {country}");
            preview.AppendLine($"เลขที่: {addressNum} ถนน: {street}");
            preview.AppendLine($"ตำบล/แขวง: {subDistrict} เขต/อำเภอ: {district}");
            preview.AppendLine($"จังหวัด: {province} รหัสไปรษณีย์: {postal}");
            preview.AppendLine($"รายละเอียดเพิ่มเติม: {addressAddon}");

            TextBox_OutputBeforeSave.Text = preview.ToString();
        }

        private void Button_Save_Click(object sender, EventArgs e)
            {
            if (string.IsNullOrWhiteSpace(TextBox_Name.Text) || string.IsNullOrWhiteSpace(TextBox_Surname.Text))
            {
                MessageBox.Show("กรุณากรอกชื่อและนามสกุล", "ข้อมูลไม่ครบถ้วน", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string birthDay = ComboBox_BirthDate.SelectedItem?.ToString() ?? "";
            string birthMonth = ComboBox_BirthMonth.SelectedItem?.ToString() ?? "";
            string birthYear = textBox_BirthYear.Text.Trim();
            string fullBirthDate = $"{birthDay} {birthMonth} {birthYear}";

            string[] row = new string[]
            {
                TextBox_Name.Text.Trim(),
                TextBox_Surname.Text.Trim(),
                comboBox1.SelectedItem?.ToString() ?? "",
                fullBirthDate,
                TextBox_Nation.Text.Trim(),
                TextBox_Age.Text.Trim(),
                ComboBox_Status.SelectedItem?.ToString() ?? "",
                TextBox_PhoneNum.Text.Trim(),
                TextBox_Email.Text.Trim(),
                TextBox_Job.Text.Trim(),
                TextBox_Country.Text.Trim(),
                TextBox_Address.Text.Trim(),
                TextBox_SubDistrict.Text.Trim(),
                TextBox_District.Text.Trim(),
                TextBox_Street.Text.Trim(),
                TextBox_Province.Text.Trim(),
                TextBox_Postal.Text.Trim(),
                TextBox_AddressAddon.Text.Trim(),
                DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

            string csvLine = string.Join(",", row.Select(field => $"\"{field.Replace("\"", "\"\"")}\""));
            string filePath = Path.Combine(Application.StartupPath, CSV_FILE_NAME);

            try
            {
                bool fileExists = File.Exists(filePath);

                using (StreamWriter sw = new StreamWriter(filePath, append: true, encoding: Encoding.UTF8))
                {
                    if (!fileExists)
                    {
                        string headers = "ชื่อ,นามสกุล,เพศ,วันเกิด,สัญชาติ,อายุ,สถานภาพ,เบอร์โทร,อีเมล,อาชีพ,ประเทศ,เลขที่อยู่,ตำบล,เขต,ถนน,จังหวัด,รหัสไปรษณีย์,รายละเอียดที่อยู่,วันที่บันทึก";
                        sw.WriteLine(headers);
                    }
                    sw.WriteLine(csvLine);
                }

                MessageBox.Show($"บันทึกข้อมูลเรียบร้อยแล้ว!\n\nไฟล์อยู่ที่:\n{filePath}",
                               "สำเร็จ", MessageBoxButtons.OK, MessageBoxIcon.Information);

                ClearAllFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"เกิดข้อผิดพลาด: {ex.Message}", "ข้อผิดพลาด", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Button_ClearPage_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("คุณต้องการล้างข้อมูลทั้งหมดใช่หรือไม่?", "ยืนยัน", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                ClearAllFields();
                TextBox_OutputBeforeSave.Clear();
            }
        }

        #endregion

        private void ClearAllFields()
        {
            TextBox_Name.Clear();
            TextBox_Surname.Clear();
            TextBox_Nation.Clear();
            TextBox_Age.Clear();
            TextBox_PhoneNum.Clear();
            TextBox_Email.Clear();
            TextBox_Job.Clear();
            TextBox_Country.Clear();
            TextBox_Province.Clear();
            TextBox_Postal.Clear();
            TextBox_District.Clear();
            TextBox_SubDistrict.Clear();
            TextBox_Street.Clear();
            TextBox_Address.Clear();
            TextBox_AddressAddon.Clear();
            textBox_BirthYear.Clear();

            ComboBox_BirthDate.SelectedIndex = -1;
            ComboBox_BirthMonth.SelectedIndex = -1;
            comboBox1.SelectedIndex = -1;
            ComboBox_Status.SelectedIndex = -1;

            TextBox_OutputBeforeSave.Clear();
        }
        private void Label_Name_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void label1_Click_1(object sender, EventArgs e) { }
        private void label1_Click_2(object sender, EventArgs e) { }
        private void Label_Personal_Info_Click(object sender, EventArgs e) { }
        private void Label_BirthDate_Click(object sender, EventArgs e) { }
    }
}